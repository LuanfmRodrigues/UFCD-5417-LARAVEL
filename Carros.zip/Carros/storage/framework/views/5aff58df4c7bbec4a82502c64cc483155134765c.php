<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.brands.brand-list',['brands' => $brands]); ?>
    <?php if (isset($__componentOriginalf1b2c10a14322a79b276865f0a0d2602f3a285ea)): ?>
<?php $component = $__componentOriginalf1b2c10a14322a79b276865f0a0d2602f3a285ea; ?>
<?php unset($__componentOriginalf1b2c10a14322a79b276865f0a0d2602f3a285ea); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projetos_Laravel\Carros\resources\views/pages/brands/index.blade.php ENDPATH**/ ?>