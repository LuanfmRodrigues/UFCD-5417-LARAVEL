<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.cars.car-list',['cars' => $cars]); ?>
    <?php if (isset($__componentOriginal5430f62ebcc092b6c1729a8eb888a27b80ec959c)): ?>
<?php $component = $__componentOriginal5430f62ebcc092b6c1729a8eb888a27b80ec959c; ?>
<?php unset($__componentOriginal5430f62ebcc092b6c1729a8eb888a27b80ec959c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projetos_Laravel\Carros\resources\views/pages/cars/index.blade.php ENDPATH**/ ?>