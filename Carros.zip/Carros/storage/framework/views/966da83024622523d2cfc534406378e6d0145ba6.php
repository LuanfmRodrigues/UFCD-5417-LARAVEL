
<h1>Cars List</h1>
<table class="table table-striped">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Brand_id</th>
        <th scope="col">Brand_Name</th>
        <th scope="col">Registration</th>
        <th scope="col">Year_of_manufacture</th>
        <th scope="col">Color</th>
        <th scope="col">Created_at</th>
        <th scope="col">Updated_at</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tbody>
        <tr>
            <th scope="row"><?php echo e($car->id); ?></th>
            <td><?php echo e($car->brand_id); ?></td>
            <td><?php echo e($car->brand->nome); ?></td>
            <td><?php echo e($car->registration); ?></td>
            <td><?php echo e($car->year_of_manufacture); ?></td>
            <td><?php echo e($car->color); ?></td>
            <td><?php echo e($car->created_at); ?></td>
            <td><?php echo e($car->updated_at); ?></td>

            <td> <button type="button" class="btn btn-success">Show</button>
                <button type="button" class="btn btn-primary">edit</button>
                <button type="button" class="btn btn-danger">Delete</button>
            </td>
        </tr>

        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\Projetos_Laravel\Carros\resources\views/components/cars/car-list.blade.php ENDPATH**/ ?>