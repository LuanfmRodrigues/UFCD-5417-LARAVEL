
<h1>Pets List</h1>
<table class="table table-striped">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Person_Id</th>
        <th scope="col">color</th>
        <th scope="col">birth_date</th>
        <th scope="col">Created_at</th>
        <th scope="col">Updated_at</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
        <tr>
            <th scope="row"><?php echo e($pet->id); ?></th>
            <td><?php echo e($pet->name); ?></td>
            <th><?php echo e($pet->person_id); ?></th>
            <td><?php echo e($pet->color); ?></td>
            <td><?php echo e($pet->birth_date); ?></td>
            <td><?php echo e($pet->created_at); ?></td>
            <td><?php echo e($pet->updated_at); ?></td>

            <td> <button type="button" class="btn btn-success">Show</button>
                <button type="button" class="btn btn-primary">edit</button>
                <button type="button" class="btn btn-danger">Delete</button>
            </td>
        </tr>

        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\Projetos_Laravel\PersonPet2\resources\views/components/pets/pets-list.blade.php ENDPATH**/ ?>