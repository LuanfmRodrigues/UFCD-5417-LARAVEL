<div class="text-center mt-5">
    <p>Website by Luan Rodrigues using <a href="https://getbootstrap.com/" class="text-primary text-decoration-none">Bootstrap</a></p>
</div>
<?php /**PATH C:\xampp\htdocs\UFCD-5417-LARAVEL-main\TestProject\resources\views/master/footer.blade.php ENDPATH**/ ?>