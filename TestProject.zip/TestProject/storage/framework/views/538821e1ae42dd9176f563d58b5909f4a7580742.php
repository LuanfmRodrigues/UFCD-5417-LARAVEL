
<h1>Details Products</h1>
<table class="table table-striped">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name_id</th>
        <th scope="col">Details</th>
        <th scope="col">Category_id</th>
        <th scope="col">Project_id</th>
        <th scope="col">Created_at</th>
        <th scope="col">Updated_at</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tbody>
        <tr>
            <th scope="row"><?php echo e($product->id); ?></th>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->details); ?></td>
            <td><?php echo e($product->category_id); ?></td>
            <td><?php echo e($product->project_id); ?></td>
            <td><?php echo e($product->created_at); ?></td>
            <td><?php echo e($product->updated_at); ?></td>

            <td><a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info btn-sm">More Details</a></td>
        </tr>

        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\UFCD-5417-LARAVEL-main\TestProject\resources\views/components/products/product-list.blade.php ENDPATH**/ ?>