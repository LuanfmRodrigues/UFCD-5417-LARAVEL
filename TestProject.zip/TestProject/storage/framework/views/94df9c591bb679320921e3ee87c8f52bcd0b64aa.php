<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.projects.project-list',['projects' => $projects]); ?>
    <?php if (isset($__componentOriginal012387835892a74d7d21f93992c4484301d2325d)): ?>
<?php $component = $__componentOriginal012387835892a74d7d21f93992c4484301d2325d; ?>
<?php unset($__componentOriginal012387835892a74d7d21f93992c4484301d2325d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UFCD-5417-LARAVEL-main\TestProject\resources\views/pages/projects/index.blade.php ENDPATH**/ ?>