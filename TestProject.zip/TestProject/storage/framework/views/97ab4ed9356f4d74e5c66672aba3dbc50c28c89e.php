<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Details Product: <?php echo e($product->name); ?></div>

                    <div class="card-body">
                        <p><strong>ID:</strong> <?php echo e($product->id); ?></p>
                        <p><strong>Name:</strong> <?php echo e($product->name); ?></p>
                        <p><strong>Category:</strong> <?php echo e($product->category->id); ?></p>

                        <h5>Detalhada:</h5>
                        <p><?php echo e($product->details); ?></p>

                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary mt-3">Voltar para Produtos</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UFCD-5417-LARAVEL-main\TestProject\resources\views/components/products/product-form-show.blade.php ENDPATH**/ ?>