
<h1>Projects List</h1>
<table class="table table-striped">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Created_at</th>
        <th scope="col">Updated_at</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tbody>
        <tr>
            <th scope="row"><?php echo e($project->id); ?></th>
            <td><?php echo e($project->name); ?></td>
            <td><?php echo e($project->created_at); ?></td>
            <td><?php echo e($project->updated_at); ?></td>


        </tr>

        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\UFCD-5417-LARAVEL-main\TestProject\resources\views/components/projects/project-list.blade.php ENDPATH**/ ?>